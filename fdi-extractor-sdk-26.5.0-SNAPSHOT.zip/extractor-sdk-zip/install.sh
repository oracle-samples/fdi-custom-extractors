#!/usr/bin/env bash

#SDK_MVN_OPT is used to provide extra maven options during installer testing.

# install_jar installs a jar artifact to the local maven repository
# usage: install_jar file pom_file
install_jar() {
	mvn $SDK_MVN_OPT install:install-file \
		-Dfile=$1 \
		-DpomFile=$2
	if [ $? -ne 0 ]; then fail; fi;
}

install_jar_javadoc() {
	mvn $SDK_MVN_OPT install:install-file \
		-Dfile=$1 \
		-DpomFile=$2 \
		-Djavadoc=$3
	if [ $? -ne 0 ]; then fail; fi;
}

install_archetype() {
	mvn $SDK_MVN_OPT install:install-file \
		-Dfile=$1 \
		-DpomFile=$2 \
		-Dpackaging=jar
	if [ $? -ne 0 ]; then fail; fi;
}

install_jar_bundle() {
   mvn $SDK_MVN_OPT install:install-file \
      -Dfile=$1 \
      -DpomFile=$2 \
      -Dpackaging=jar
   if [ $? -ne 0 ]; then fail; fi;
}

fail() {
	echo "Install failed."
	while true; do
        read -p "Please enter Y/y to close the prompt.)" yn
        case $yn in
            [Yy]* ) exit 1;;
                * ) echo "Please enter Y/y.";;
        esac
done
	exit 1
}

#install_jar "lib/oax-extractservice-public-sdk.jar" "lib/oax-extractservice-public-sdk.pom"
install_archetype "lib/extractservice-archetype.jar" "lib/extractservice-archetype.pom"
install_jar "lib/oax-extractservice-custom.jar" "lib/oax-extractservice-custom.pom"
mvn $SDK_MVN_OPT archetype:crawl -Dcatalog='${settings.localRepository}/archetype-catalog.xml'
if [ $? -ne 0 ] ; then fail ; fi ;

echo "Install successful."
	while true; do
        read -p "Please enter Y/y to close the prompt.)" yn
        case $yn in
            [Yy]* ) exit 1;;
                * ) echo "Please enter Y/y.";;
        esac
done
	exit 1
